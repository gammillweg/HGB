package com.example.hgbexample;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import appview.GraphicsView;
import hgb.HGBShared;
import model.GameBoardSetup;
import model.GameShared;
import model.UserOptionsShared;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
   private final String TAG = this.getClass().getSimpleName();
   private GraphicsView graphicsView;
   private GameBoardSetup gameBoardSetup = null;
   private GameShared gameShared = null;
   private UserOptionsShared userOptionsShared = null;
   private HGBShared hgbShared = null;

   private boolean dbNumberCellsFlg = true;

   @Override
   protected void onCreate(Bundle savedInstanceState)
   {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);
      Toolbar toolbar = findViewById(R.id.toolbar);
      setSupportActionBar(toolbar);

      graphicsView = findViewById(R.id.graphicsview);

      FloatingActionButton fab = findViewById(R.id.fab);
      fab.setOnClickListener(new View.OnClickListener()
      {
         @Override
         public void onClick(View view)
         {
            //Snackbar.make(view, "Not implemented, does nothing", Snackbar.LENGTH_LONG)
            //      .setAction("Action", null).show();
            graphicsView.clearCollectTouchedCells();
            graphicsView.invalidate();
         }
      });

      // CodeProject comment:  CWG (cwg) may be mentioned here and there.
      // CWG:  Classic War Game.  A game I tried to write; but fell short.
      // To much for one retired programmer.  Besides... I find I am much
      // better at foundational stuff (like HGB) than actually writing a game.
      
      if (gameBoardSetup == null)
      {
         // This is the ONE and ONLY place UserOptionsShared is created.
         // (note that cwgShared has NOT been created yet.
         // cwgShared will be fed to userOptionsShared in createGameBoard()
         userOptionsShared = new UserOptionsShared();

         // !!! Here a thread is run !!!
         // Create a new hive and land in the background
         if (createGameBoard(userOptionsShared) == false)
         {
            Toast.makeText(this, "Game failed to initiate", Toast.LENGTH_LONG).show();
            finish();
         }

         // TODO -- here we start the thing up ONE time ... need other code for restarts
         graphicsView.setPath();
         graphicsView.localInit();
         graphicsView.invalidate();
      }
   }

   @Override
   public boolean onCreateOptionsMenu(Menu menu)
   {
      // Inflate the menu; this adds items to the action bar if it is present.
      getMenuInflater().inflate(R.menu.menu_main, menu);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item)
   {
      // Handle action bar item clicks here. The action bar will
      // automatically handle clicks on the Home/Up button, so long
      // as you specify a parent activity in AndroidManifest.xml.
      int id = item.getItemId();

      //if (id == R.id.action_settings)
      //{
         //return true;
      //}

      try
      {
         switch (item.getItemId())
         {
            case R.id.newGame:
               this.newGame();
               return true;

            case R.id.zoomIn:
               this.zoomIn();
               return true;

            case R.id.zoomOut:
               this.zoomOut();
               return true;

            case R.id.hiveLarger:
               this.hiveLarger();
               return true;

            case R.id.hiveSmaller:
               this.hiveSmaller();
               return true;

            case R.id.report:
               report();
               return true;

//            case R.id.cellSizeLarger:
//               graphicsView.clearCollectTouchedCells();
//               this.cellSizeLarger();
//
//               double cellsize = gameShared.getCellSize();
//               String msg = "Cell size:  " + cellsize + " (hit New Game)";
//               Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
//               return true;
//
//            case R.id.cellSizeSmaller:
//               graphicsView.clearCollectTouchedCells();
//               this.cellSizeSmaller();
//
//               cellsize = gameShared.getCellSize();
//               msg = "Cell size:  " + cellsize + " (hit New Game)";
//               Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
//               return true;

            case R.id.numberCells:
               dbNumberCellsFlg = !dbNumberCellsFlg;
               graphicsView.setDBNumberCellsFlg(dbNumberCellsFlg);
               graphicsView.invalidate();
               return true;

            default:
               return super.onOptionsItemSelected(item);
         }
      }
      catch(Exception excp)
      {
         Log.e("FatalError:  ", excp.toString());
         return false;
      }
   }

   //=============================================================================

   /**
    * This game board creation my be just a tad more complex that this small
    * game requires (with the GameShared and all).  But much of the set up
    * is taken from CWG.  And CWG is a much more complex game.  Plus (at the moment)
    * CWG runs the game board setup in a background thread.  (I intend
    * to change that (someday).)
    *
    * @return returns false on error, true on success
    */
   private boolean createGameBoard(UserOptionsShared userOptionsShared)
   {
      if (gameBoardSetup != null)
      {
         gameBoardSetup = null;
      }
      gameBoardSetup = new GameBoardSetup();
      // The ONE and ONLY call to initialize classes and defaults for the HGB and Units
      // (HGBShared, CWGShared and GameUnit, defaultRoseRings, defaultCellSize and
      // defaultHiveOrigin)
      this.gameShared = gameBoardSetup.gameBoardInitialize(userOptionsShared);
      if (gameShared == null) return false;
      this.hgbShared = gameShared.getHGBShared();
      if (hgbShared == null) return false;

      // GameShared holds the hive options and the graphicsView gets
      // the hive options from GameShared.
      graphicsView.setGameShared(gameShared);
      return true;
   }

   //==========================================================================
   public void newGame()
   {
      graphicsView.clearCollectTouchedCells();
      gameShared.setCellSize(36);
      gameShared.setRoseRings(4);

      graphicsView.clearCollectTouchedCells();
      gameBoardSetup.initHive();
      graphicsView.invalidate();
   }

   public void zoomIn()
   {
      double cellSize = gameShared.getCellSize();
      cellSize += gameShared.getZoomStep();
      gameShared.setCellSize(cellSize);

      // in testAddUnits() the old path is cleared and a new path for each
      // unit created and a new unityPath is created (as a combination of each unit path)

      graphicsView.clearCollectTouchedCells();
      gameBoardSetup.initHive();
      graphicsView.invalidate();
   }

   public void zoomOut()
   {
      double cellSize = gameShared.getCellSize();
      cellSize -= gameShared.getZoomStep();
      gameShared.setCellSize(cellSize);

      graphicsView.clearCollectTouchedCells();
      gameBoardSetup.initHive();
      graphicsView.invalidate();
   }

   public void hiveLarger()
   {
      int roseRings = gameShared.getRoseRings();
      roseRings++;

      int maxRoseRings = gameShared.getMaxRoseRings();
      roseRings = (roseRings >= maxRoseRings) ? maxRoseRings : roseRings;
      userOptionsShared.setUserRoseRings(roseRings);

      graphicsView.clearCollectTouchedCells();
      gameBoardSetup.initHive();
      graphicsView.invalidate();

      // No longer recreates a hive
   }

   public void hiveSmaller()
   {
      int roseRings = gameShared.getRoseRings();
      roseRings--;

      roseRings = (roseRings < 0) ? 0 : roseRings;
      userOptionsShared.setUserRoseRings(roseRings);

      graphicsView.clearCollectTouchedCells();
      gameBoardSetup.initHive();
      graphicsView.invalidate();

      // No longer recreates a hive
   }

//   // Sets a new "default" cell size for next new game
//   public void cellSizeLarger()
//   {
//      double cellSize = gameShared.getCellSize();
//      cellSize += gameShared.getZoomStep();
//      userOptionsShared.setUserCellSize(cellSize);
//   }
//
//   // Sets a new "default" cell size for next new game
//   public void cellSizeSmaller()
//   {
//      double cellSize = gameShared.getCellSize();
//      cellSize -= gameShared.getZoomStep();
//      userOptionsShared.setUserCellSize(cellSize);
//   }

   public void report()
   {
      int total = hgbShared.getCellAryLen();
      int val = total/10;
      int waste = val * 3;
      int cells = total - waste;

      //double cellSize = hgbShared.getCellSize();
      int roses = hgbShared.getRoseCount();
      int rings = hgbShared.getRoseRings();

      //String msg = cells + " cells " + roses + " roses " + rings + " rings,  Cell size:  " + cellSize;
      String msg = rings + " rings, " + roses + " roses, " + cells + " cells"; //, Cell size: " + cellSize;
      Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
   }

}
