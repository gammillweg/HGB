package model;

import java.util.HashSet;

import hgb.HGBShared;

/**
 * Created by weg on 10/26/2016.
 * Copied from CWGUtils
 * Some of these may not be useful to HexChase; but it was easier to
 * simply copy them all over so they will be available.
 */

public class GameHGBUtils
{
   public GameHGBUtils(){}

   //===========================================================================
   /**
    * This little set of methods were pulled out of HGBProgressions and duplicated
    * here.  In that I need the result for initializing CWGShared.cellContentALAry.
    * But, even though HGBShared.cellIndices is available in HGBShared, it isn't
    * there in a timely manor.  I need it sooner than HGBLocator is initialized.
    * I did a lot of moving CWG initializations to wait for maze generations; but.
    * in the end, decided, I would rather leave my CWG initializations as they are
    * and duplicate some code here.
    */

   /**
    * Compute the cell indices (a simple incremental loop). (Recall that roses
    * are in increments of 10 (from 0) and there 6 sides around each rose for
    * a total of 7 cells.)
    *
    * @return an array of cell indices exclusive of unused array indecies
    *        (Does not include unused cells cell 10 is stored in rtn[7]
    */
   protected int[] getCellIndices(int roseRings)
   {
      int roseCnt = countAllRoses(roseRings);
      int[] cellIndices = new int[roseCnt * (HGBShared.SIDES + 1)];
      int roseIndex;
      int index = 0;
      for (int inx = 0; inx < roseCnt; inx++)
      {
         roseIndex = inx * 10;
         for (int side = 0; side < HGBShared.SIDES + 1; side++)
         {
            cellIndices[index++] = roseIndex + side;
         }
      }

      return cellIndices;
   }

   // Count the number of roses by roseRing
   // NOTE: Rose 0 is COUNTED as a rose ring, thus rose ring 1 is 0, 2 is
   // 10-60, 3 70-80, 4 190-360
   // for a total of 37 roses.
   protected int countAllRoses(int roseRings)
   {
      int roseCnt = 0;
      for (int inx = 0; inx < roseRings; inx++)
      {
         roseCnt += countRosesPerRing(inx);
      }
      return roseCnt;
   }

   protected int countRosesPerRing(int roseRing)
   {
      int[] range = roseRingRange(roseRing);
      return ((range[1] - range[0]) / 10) + 1;
      // int[] roseIndicesAry = progressions.rosesPerRing(range);
      // return roseIndicesAry.length;
   }

   // The return is a int array of length == 2, where
   //	[0] = the first rose in the rose ring
   // [1] = the last rose in the rose ring
   // rose ring == 0 is special:  [0] = 0, and [1] = 0;
   // as rose ring == 0 is not a true rose ring, rather the center of a rose
   protected int[] roseRingRange(int roseRing)
   {
      // This is a very short counting loop.  It would be very nice
      // if I could figure out the math to simply calculate the number of
      // roses in a rose ring and some way to know the index of the first rose.
      // BUT... I don't see it.  On the other hand, I have previously written
      // code in a loop to step from one rose ring to the next as I filled a
      // SparseArray with all the ranges for all the rose rings.  Hence, here,
      // use previously tested code, and start form 0 and loop upwards
      // till I get the rose ring I want.

      int cnt = 0;
      int start = 0;
      int end = 0;

      for (int inx = 0; inx < roseRing; inx++)
      {
         start = end + 10;
         cnt += 6;
         end = (((start/10) + cnt) * 10) - 10;
      }

      int[] range = new int[2];
      range[0] = start;
      range[1] = end;

      return range;
   }

   //===========================================================================


   //===========================================================================
   /**
    * Convert a HashSet<Integer> to int[]
    * This works: Integer[] ary = hs.toArray(new Integer[hs.size()]);
    * But... this gives an int[] rather than a Integer ary
    * @param hs a HashSet of Integer
    * @return an allocated array of int
    */
   public int[] hashSetToIntAry(HashSet<Integer> hs)
   {
      if (hs == null) return null;
      int[] ary = new int[hs.size()];
      int inx = 0;
      for (int item : hs) ary[inx++] = item;
      return ary;
   }

   //===========================================================================

   /**
    * Convert a int[] to an allocated HashSet<Integer>
    * @return a HashSet content of input int[]
    */
   public HashSet<Integer> aryToHashSet(int[] ary)
   {
      HashSet<Integer> hs = new HashSet<Integer>(ary.length);
      for (int inx : ary) hs.add(inx);
      return hs;
   }

   //===========================================================================
}
