package model;

import android.graphics.Path;

import java.util.LinkedList;

import hgb.HGBLocator;
import hgb.HGBShared;

/**
 * Created by weg on 10/26/2016.
 * This stuff (mostly) copied from CWGShared
 */

public class GameShared
{
   private final String TAG = this.getClass().getSimpleName();

   public GameShared(HGBShared hgbShared, GameHGBUtils gameHGBUtils)
   {
      this.hgbShared = hgbShared;
      this.gameHGBUtils = gameHGBUtils;

      //===================================================================
      // Here Set Once and only once CWG Defaults
      // TODO -- need to let the user decide what the default size is
      // Minimum Rose Rings is a final in WedgeSoftHGB set to 0

      this.maxRoseRings = 60;

      //for debug: 6 rings; 14f size  // 11 and 8f is nice
      // Large test default 20 cell size 6f
      // Medium test default 12 cell size 9f
      // Small test default 6 cell size  14f
      this.defaultRoseRings  = 4;
      this.setRoseRings(defaultRoseRings);

      this.defaultCellSize = 25f;//16f; //14f; ;//49f;
      this.setCellSize(defaultCellSize);

      // Note that in Graphics View, setHiveOrigin() is called to
      // center the hive, so these defaults are not used.
      this.defaultHiveOrigin = new float[2];
      this.defaultHiveOrigin[0] = 350f;
      this.defaultHiveOrigin[1] = 450f;

      this.hiveOrigin = new float[2];
      this.setHiveOrigin(defaultHiveOrigin);

      this.zoomStep = 5d;
      //===================================================================
      this.dbShowCellNumbers = false;
      //this.dbShowCellNumbers = true;

      //this.dbDrawHivePath = false;
      this.dbDrawHivePath = true;
      //===================================================================
   }

   private HGBShared hgbShared = null;
   public HGBShared getHGBShared() { return hgbShared; }

   private  HGBLocator hgbLocator = null;
   public void setHGBLocator(HGBLocator hgbLocator) { this.hgbLocator = hgbLocator; }
   public HGBLocator getHGBLocator() { return hgbLocator; }

   private GameHGBUtils gameHGBUtils = null;
   public GameHGBUtils getGameHGBUtils() { return gameHGBUtils; }

   public boolean dbShowCellNumbers = true;
   public boolean dbShowOnlyRoseNumbers = true;

   public boolean dbDrawHivePath = true;
   //======================================================================

   //==================== Hive Data =====================
   // This class is created ONE time and is its ONE AND ONLY instance.
   // It is created within BoardSetup.gameBoardInitialize(), and the
   // following defaults are passed to this constructor from
   // BoardSetup.gameBoardInitialize().  (They are not "final" (constant);
   // but are effectively the same thing.)

   private int defaultRoseRings;
   public int getDefaultRoseRings() { return this.defaultRoseRings; }

   // pretty much max on my kindle;
   private double defaultCellSize;
   public double getDefaultCellSize() { return this.defaultCellSize;  }

   private float[] defaultHiveOrigin;
   public float[] getDefaultHiveOrigin() { return this.defaultHiveOrigin; }

   //-----------------------------------------------------------------


   //-----------------------------------------------------------------
   // define the hive...
   // passed through to HGBShared

   private int maxRoseRings;
   public int getMaxRoseRings() { return this.maxRoseRings; }
   public void setMaxRoseRings(int maxRoseRings)
   {
      this.maxRoseRings = maxRoseRings;
      hgbShared.setMaxRoseRings(maxRoseRings);
   }

   private int roseRings;
   public int getRoseRings() { return roseRings; }
   public void setRoseRings(int roseRings)
   {
      this.roseRings = roseRings;
      if (roseRings > this.maxRoseRings) this.roseRings = this.maxRoseRings;
      if (roseRings < 0) this.roseRings = 0;
      hgbShared.setRoseRings(roseRings);
   }

   private double cellSize;
   public double getCellSize() { return cellSize; }
   public void setCellSize(double cellSize)
   {
      if (cellSize < 0) cellSize = 0;
      this.cellSize = cellSize;
      hgbShared.setCellSize(cellSize);
   }

   private float[] hiveOrigin;
   public float[] getHiveOrigin() { return hiveOrigin; }
   public void setHiveOrigin(float[] hiveOrigin)
   {
      this.hiveOrigin[0] = hiveOrigin[0];
      this.hiveOrigin[1] = hiveOrigin[1];
      hgbShared.setHiveOrigin(hiveOrigin);
   }

   //-----------------------------------------------------------------
   private double zoomStep;
   public double getZoomStep() { return zoomStep; }
   public void setZoomStep(double zoomStep) { this.zoomStep = zoomStep; }

   //-----------------------------------------------------------------

   private Path hivePath = null;
   private Path basePath = null;
   public Path getHivePath() { return hivePath; }
   public Path getBasePath() { return basePath; }

   public void setHivePath(Path hivePath, Path basePath)
   {
      this.hivePath = hivePath;
      this.basePath = basePath;
   }
   //-----------------------------------------------------------------

   //-----------------------------------------------------------------

}
