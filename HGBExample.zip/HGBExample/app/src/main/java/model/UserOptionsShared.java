package model;

/**
 * Created by weg on 3/8/2016.
 * A class to hold user options.
 * GameShared is the master, UserOptionsShared is the slave
 * UserOptionsShared feeds GameShared
 *
 * TODO -- these MUST be stored on the device and resorted on startup
 * For now... used more as a debug feature.
 */
public class UserOptionsShared
{
   public UserOptionsShared()
   {
      userRoseRingsFlag = false;
      userCellSizeFlag = false;
      userZoomStepsFlags = false;
   }

   GameShared gameShared = null;
   public void setGameShared(GameShared gameShared)
   {
      // All of this, using the Flag stuff, is necessary in that
      // gameShared does not exist when UserOptionsShared is created

      if (gameShared != null)
      {
         this.gameShared = gameShared;

         if (userMaxRoseRingsFlag)
         {
            this.gameShared.setMaxRoseRings(userMaxRoseRings);
         }
         else
         {
            this.userMaxRoseRings = this.gameShared.getMaxRoseRings();
         }

         if (userRoseRingsFlag)
         {
            this.gameShared.setRoseRings(userRoseRings);
         }
         else
         {
            this.userRoseRings = this.gameShared.getDefaultRoseRings();
         }

         if (userCellSizeFlag)
         {
            this.gameShared.setCellSize(userCellSize);
         }
         else
         {
            this.userCellSize = this.gameShared.getDefaultCellSize();
         }

         if (userZoomStepsFlags)
         {
            this.gameShared.setZoomStep(userZoomSteps);
         }
         else
         {
            userZoomSteps = this.gameShared.getZoomStep();
         }
      }
   }

   private boolean userMaxRoseRingsFlag;
   private int userMaxRoseRings;
   public int getMaxUserRoseRings() { return userMaxRoseRings; }
   public void setMaxUserRoseRings(int userMaxRoseRings)
   {
      this.userMaxRoseRings = userMaxRoseRings;
      if (gameShared != null)
      {
         this.gameShared.setMaxRoseRings(userMaxRoseRings);
      }
      userMaxRoseRingsFlag = true;
   }

   private boolean userRoseRingsFlag;
   private int userRoseRings;
   public int getUserRoseRings() { return userRoseRings; }
   public void setUserRoseRings(int userRoseRings)
   {
      this.userRoseRings = userRoseRings;
      if (gameShared != null)
      {
         this.gameShared.setRoseRings(userRoseRings);
      }
      userRoseRingsFlag = true;
   }

   private boolean userCellSizeFlag;
   private double userCellSize;
   public double getUserCellSize() { return userCellSize; }
   public void setUserCellSize(double userCellSize)
   {
      this.userCellSize = userCellSize;
      if (gameShared != null)
      {
         this.gameShared.setCellSize(userCellSize);
      }
      userCellSizeFlag = true;
   }

   private boolean userZoomStepsFlags;
   private double userZoomSteps;
   public double getUserZoomStep() { return userZoomSteps; }
   public void setUserZoomStep(double userZoomSteps)
   {
      this.userZoomSteps = userZoomSteps;
      if (gameShared != null)
      {
         this.gameShared.setZoomStep(userZoomSteps);
      }
      userZoomStepsFlags = true;
   }

   // hiveOrigin is NOT user settable

}
