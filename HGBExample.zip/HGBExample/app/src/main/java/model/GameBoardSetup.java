package model;

import android.graphics.Path;
import android.graphics.RectF;

import hgb.HGBCellPack;
import hgb.HGBGenerateHive;
import hgb.HGBLocator;
import hgb.HGBShared;
import hgb.HGBUtils;

/**
 * Created by weg on 10/26/2016.
 */

public class GameBoardSetup
{
   private final String TAG = this.getClass().getSimpleName();

   //-----------------------------------------
   private HGBGenerateHive hgbGenerateHive = null;

   // Should be the only instance of HGBLocator.
   // Others should used HGBUtils or HGBShared
   // But here the locator must be initialized
   // TODO -- see if can initialize the locator from Generate after the hive has been generated.
   // so as to get rid of this one instance of use of HGBLocator
   private HGBLocator hgbLocator = null;
   private HGBUtils hgbUtils = null;

   private Path basePath = null;
   private Path hivePath = null;
   private RectF baseInscribedRect = null;
   private RectF baseSuberscribedRectF = null;

   //-----------------------------------------

   // Called ONE time when the application is created from
   // GraphicFragments.onActivityCreated().
   // Create the ONE and ONLY instances of HGBShared, GameShared
   // Also sets the defaults for the Hexagon Game Board (HGB).

   private GameShared gameShared = null;  // Common data with in the Classic War Game app
   private GameHGBUtils gameHGBUtils = null;    // Common miscellaneous methods
   private HGBShared hgbShared = null;  // Common data within isolated class WedgewegHGB
//-----------------------------------------

   public GameShared gameBoardInitialize(UserOptionsShared userOptionsShared)
   {
      //====================================================
      // On and ONLY ONE instance of HGBShared and GameShared
      this.hgbShared = new HGBShared();
      this.gameHGBUtils = new GameHGBUtils();

      this.gameShared = new GameShared(hgbShared, gameHGBUtils);

      userOptionsShared.setGameShared(gameShared);

      //========================================================

      // Set User chosen Hive variables

      // Here take care of insuring that UserOptions override CWGShared
      // defined options.
      // In CWGShared's constructor maxRoseRings, defaultRoseRings, defaultCellSize
      // defaultHiveOrigin and zoomSteps are all defined along with their mate
      // variables roseRings, cellSize, and hiveOrigin.  These are in turn
      // passed onto HGBShared (from CWGShared).
      // In UserOptionsShared.setCWGShared() these are checked against a
      // boolean to determine if the user has set an option.  If so, then
      // the option value is passed to CWGShared's mate variable (roseRings
      // rather than defaultRoseRings) and from CWGShared passed onto HGBShared.

      // Here we insure that the IF SET... the user variable is used rather
      // than the CWGShared default variable.

      // Minimum Rose Rings is 0
      int defaultRoseRings;
      int userRoseRings;
      defaultRoseRings = gameShared.getDefaultRoseRings();
      userRoseRings = userOptionsShared.getUserRoseRings();
      if (userRoseRings != defaultRoseRings)
      {
         gameShared.setRoseRings(userRoseRings);
      }

      double defaultCellSize;
      double userCellSize;
      defaultCellSize =  gameShared.getDefaultCellSize();
      userCellSize = userOptionsShared.getUserCellSize();
      if (userCellSize != defaultCellSize)
      {
         gameShared.setCellSize(userCellSize);
      }

      // Here do the initial setup for the HGB and filling of hgbShared
      initHive();

      return gameShared;
   }

   /**
    * Initialize all Hive data
    */
   public void initHive()
   {
      // =========================================================

      // Important: Rose 0 and it's 6 petals is counted as ring 1.
      // It follows ...
      // In GenerateHive.generateHive_Main() one finds two loops
      // "for (int roseRing = 0; roseRing < roseRings; roseRing++)."
      // Thus, roseRing = 0 (as index in the for loop) IS ring 1.
      // Thus, if roseRings == 3, one steps through 0, 1, 2 (THREE rings).
      // (This long note -- as I did once become confused and wondered
      // why I needed roseRing = 4 to generate 3 rings. I was NOT
      // properly counting rose 0 as a ring.)

      // this.roseRings = 2; // 49 cells, arrayLen 70
      // this.roseRings = 3; // 133 cells, arrayLen 190
      // this.roseRings = 4; // 259 cells, arrayLen 370
      // this.roseRings = 5; // 427 cells, arrayLen 610
      // this.roseRings = 6; // 637 cells, arrayLen 910
      // this.roseRings = 7; // 889 cells, arrayLen 1270

      // ------------------------------------------

      // ----------------
		/*
		 * from manifest <activity android:name=".MainActivity"
		 * android:label="@string/app_name" android:hardwareAccelerated="false"
		 * --- working orientation ---
		 * android:screenOrientation="sensorLandscape"> or
		 * android:screenOrientation="sensorPortrait">
		 */
      // ----------------

      // Set for horizontal ordination of the device.
      // (OrientationRadians.[Portrait or Landscape])
      // hgbShared.setVertexRadians(HGBShared.OrientationRadians.Portrait);
      hgbShared.setVertexRadians(HGBShared.OrientationRadians.Landscape);

      // set the default cellSize, pass it onto hgbHexBase() and
      // create a basePath (a hexagon path about (0,0))
      double cellSize = gameShared.getCellSize();
      hgbShared.setCellSize(cellSize);
      // =========================================================

      generateHive();
   }

   private void generateHive()
   {
      if (hgbGenerateHive == null)
      {
         hgbGenerateHive = new HGBGenerateHive(hgbShared);
      }

      // generateHive_Main gets roseRings and size of cell from hgbShared.
      // AND... hgbShared gets roseRings and cellSize from gameShared
      hgbGenerateHive.generateHive_Main();

      // Gets roseRings and hiveOrigin and from hgbShared (which gets
      // roseRings and cellSize and hiveOrigin from gameShared

      // The locator can not be created until the hive has been generated.
      // Is passed to gameShared for distribution.
      if (hgbLocator == null)
      {
         hgbLocator = new HGBLocator(hgbShared);
         hgbShared.setHGBLocator(hgbLocator);

         hgbUtils = new HGBUtils(hgbShared);
         hgbShared.setHGBUtils(hgbUtils);
      }
      hgbLocator.locatorInitialize();

      // Create the Paths used to draw entity units and pass onto the view
      //baseInscribedRect = hgbShared.getBaseInscribeRectF();
      //mapUnits.mapUnitPaths(baseInscribedRect);
      //gameShared.setBaseInscribedRect(baseInscribedRect);

      createHivePath();
   }

   // =========================================================

   // =========================================================
   // Copy the basePath about, offset per origin (adding to the path).
   private void createHivePath()
   {
      if (hivePath == null)
      {
         hivePath = new Path();
      }
      else
      {
         hivePath.reset();
      }

      // Create a single hexagon centered around (0,0) to be copied about
      createBaseSingleHexagonPath();

      for (int inx = 0; inx < hgbShared.getCellAryLen(); inx++)
      {
         HGBCellPack hgbCellPack = hgbShared.getCellPack(inx);

         if (hgbCellPack == null)
            continue;
         float[] origin = hgbCellPack.getOrigin();
         if (origin == null)
            continue;

         // Offset the origin as added to the path
         hivePath.addPath(basePath, origin[0], origin[1]);
      }

      // Pass it onto the view
      gameShared.setHivePath(hivePath, basePath);
   }

   // Create a single hexagon path about (0,0), which will be copied
   // about, offset per origin, for each cell, to create
   // the hivePath.
   private void createBaseSingleHexagonPath()
   {
      if (basePath == null)
      {
         basePath = new Path();
      }
      else
      {
         basePath.reset();
      }

      float[][] baseVertices = hgbShared.getBaseVertices();

      basePath.moveTo(baseVertices[0][0], baseVertices[0][1]);

      for (int inx = 0; inx < HGBShared.SIDES - 1; inx++)
      {
         basePath.lineTo(baseVertices[inx + 1][0], baseVertices[inx + 1][1]);
      }

      // the last line, to close it up.
      basePath.lineTo(
            baseVertices[HGBShared.SIDES - 1][0],
            baseVertices[HGBShared.SIDES - 1][1]);

      basePath.lineTo(baseVertices[0][0], baseVertices[0][1]);
      basePath.close();
   }
}
